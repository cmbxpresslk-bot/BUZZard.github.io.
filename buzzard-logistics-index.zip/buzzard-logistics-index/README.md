# Buzzard Logistics — Static Website

A responsive, single-page static website for Buzzard Logistics.

## Files

- `index.html` — complete website, styles and client-side interactions.
- `assets/buzzard-logo.png` — transparent-background version of the supplied green logo. The logo artwork was not redrawn.
- `build.mjs` — copies the static site into `dist/` for deployment.
- `package.json` — includes the `npm run build` command.

## Run locally

You can open `index.html` directly in a browser. For a local server, use any static file server.

To generate the deployment folder:

```bash
npm run build
```

The generated website is in `dist/`.

## Cloudflare Pages

Connect the GitHub repository and set:

- Framework preset: None
- Build command: `npm run build`
- Build output directory: `dist`
- Root directory: repository root

## Before launch

1. Replace `https://buzzard-logistics.pages.dev/` in the canonical URL, Open Graph URL and JSON-LD `url` fields in `index.html` with the final website URL.
2. Confirm the Google Maps embed points to the official Wattala location. The "Open saved map pin" link uses the supplied Google Maps short link.
3. Test every image on the live website. Images are loaded from Unsplash CDN and therefore require an internet connection; download and locally host appropriately licensed image assets before production if preferred.
4. Review and complete the Privacy Notice and Website & Service Notice with appropriate legal advice.
5. Confirm all listed services and carrier booking options are actually available before making commercial claims.

## Important functionality note

The quotation form validates required fields and opens WhatsApp (`+94 77 011 7354`) with the customer's enquiry. It does not save enquiries to a website database or send email automatically.

The carrier section uses text-only names and neutral "carrier options" wording. It does not assert formal partnerships or agency appointments.
